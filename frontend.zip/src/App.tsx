import { useEffect, useState } from "react";
import { getProducts } from "./services/productService";
import type { Product } from "./types/Product";
import ProductCard from "./components/ProductCard";


// Swiper imports

import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import "swiper";





const App = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    getProducts()
      .then(setProducts)
      .catch((err) => console.error("Ürünler alınamadı:", err));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="font-avenirb text-[45px] mb-6 text-center">Product List</h1>
        <Swiper
          spaceBetween={24}
          slidesPerView={1.2}
          breakpoints={{
            640: { slidesPerView: 2.2 },
            1024: { slidesPerView: 3.2 },
            1280: { slidesPerView: 4 },
          }}
          navigation
          modules={[Navigation]}
        >
          {products.map((product, index) => (
            <SwiperSlide key={index}>
              <ProductCard product={product} />
            </SwiperSlide>
          ))}
      </Swiper>


    </div>
  );
};

export default App;