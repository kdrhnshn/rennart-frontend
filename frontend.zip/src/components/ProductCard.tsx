import { useState } from "react";
import type { Product } from "../types/Product";

interface Props {
  product: Product;
}

const ProductCard = ({ product }: Props) => {
  const [selectedColor, setSelectedColor] = useState<"yellow" | "rose" | "white">("yellow");

  const colorOptions: {
    key: "yellow" | "rose" | "white";
    label: string;
    hex: string;
  }[] = [
    { key: "yellow", label: "Yellow Gold", hex: "#E6CA97" },
    { key: "white", label: "White Gold", hex: "#D9D9D9" },
    { key: "rose", label: "Rose Gold", hex: "#E1A4A9" },
  ];

  return (
    <div className="w-full bg-white p-4 shadow rounded-lg border hover:shadow-lg transition">
      <img
        src={product.images[selectedColor]}
        alt={product.name}
        className="w-full h-48 object-contain mb-4"
      />

      <h2 className="font-montserratm text-[15px] mb-1 ">{product.name}</h2>
      <p className="font-montserratr text-[15px] mb-1">${product.priceUSD} USD</p>
      <p className="font-avenirb text-[14px] mb-3">{product.rating} / 5 ⭐</p>

      {/* Renk seçici */}
      <div className="flex items-center gap-3 mb-2">
        {colorOptions.map((color) => (
          <button
            key={color.key}
            onClick={() => setSelectedColor(color.key)}
            className={`w-5 h-5 rounded-full border-2 transition ${
              selectedColor === color.key ? "border-black" : "border-gray-300"
            }`}
            style={{ backgroundColor: color.hex }}
          ></button>
        ))}
      </div>

      <p className="font-avenirb text-[12px]">{colorOptions.find(c => c.key === selectedColor)?.label}</p>
    </div>
  );
};

export default ProductCard;