import React, { useRef, useEffect, useState } from 'react';
import ProductCard from './ProductCard';
import type { Product } from '../types/Product';
import { getProducts } from '../services/productService';

const ProductSlider: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getProducts()
      .then(setProducts)
      .catch((error) => console.error("Ürünler alınamadı:", error));
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <div className="relative w-full">
      <h2 className="text-2xl font-bold text-center my-6">Ürün Listesi</h2>

      {/* Sol ok */}
      <button
        onClick={() => scroll('left')}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow rounded-full w-8 h-8 flex items-center justify-center"
      >
        ←
      </button>

      {/* Scrollable container */}
      <div
        ref={scrollRef}
        className="flex overflow-x-auto space-x-4 px-10 scrollbar-hide scroll-smooth"
      >
        {products.map((product, index) => (
          <div key={index} className="min-w-[250px] max-w-[250px] flex-shrink-0">
            <ProductCard product={product} />
          </div>
        ))}
      </div>

      {/* Sağ ok */}
      <button
        onClick={() => scroll('right')}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow rounded-full w-8 h-8 flex items-center justify-center"
      >
        →
      </button>
    </div>
  );
};

export default ProductSlider;
